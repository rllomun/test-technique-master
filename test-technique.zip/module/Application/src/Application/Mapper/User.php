<?php
namespace Application\Mapper;

use Doctrine\ORM\EntityRepository;


class User extends EntityRepository
{

}